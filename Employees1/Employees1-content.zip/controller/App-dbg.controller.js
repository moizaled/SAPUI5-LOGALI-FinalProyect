// @ts-nocheck
sap.ui.define([
    "sap/ui/core/mvc/Controller",
],
    function (Controller) {

        return Controller.extend("logaligroup11.Employees1.controller.App", {


            onInit: function () {

            }

        });

    });